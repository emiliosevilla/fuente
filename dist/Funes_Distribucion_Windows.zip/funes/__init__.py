"""Funes Knowledge Base ETL Package."""
__version__ = "0.1.0"
