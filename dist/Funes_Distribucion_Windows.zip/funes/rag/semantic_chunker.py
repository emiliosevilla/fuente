import re
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


class SemanticChunker:
    """Divide documentos respetando la jerarquía de encabezados Markdown, párrafos y bloques de significado."""

    def __init__(self, max_chunk_size: int = 1000, overlap: int = 200):
        self.max_chunk_size = max_chunk_size
        self.overlap = overlap

    def chunk_markdown(self, md_content: str, source_file: str) -> List[Dict[str, Any]]:
        """Aplica chunking estructurado y semántico sobre Markdown verbatim."""
        safe_source_id = re.sub(r"[^a-zA-Z0-9_-]", "_", source_file)
        
        # Dividir por encabezados (#, ##, ###)
        sections = re.split(r"\n(?=#+\s)", md_content)
        chunks = []

        for sec in sections:
            sec_text = sec.strip()
            if not sec_text:
                continue

            # Extrae el encabezado si existe
            header_match = re.match(r"^(#+\s+[^\n]+)", sec_text)
            current_header = header_match.group(1) if header_match else "General"

            # Si la sección excede el tamaño máximo, dividir por párrafos y frases
            if len(sec_text) > self.max_chunk_size:
                paragraphs = sec_text.split("\n\n")
                current_chunk = []
                current_len = 0

                for p in paragraphs:
                    p_len = len(p)
                    # Manejar párrafos gigantes individuales
                    if p_len > self.max_chunk_size:
                        sub_sentences = re.split(r"(?<=[.!?])\s+", p)
                        for sentence in sub_sentences:
                            s_len = len(sentence)
                            if current_len + s_len > self.max_chunk_size and current_chunk:
                                chunk_text = " ".join(current_chunk)
                                chunks.append(self._create_chunk_dict(chunk_text, source_file, safe_source_id, current_header, len(chunks)))
                                # Aplicar solapamiento (overlap) del fragmento anterior
                                overlap_text = chunk_text[-self.overlap:] if len(chunk_text) > self.overlap else chunk_text
                                current_chunk = [overlap_text, sentence] if self.overlap > 0 else [sentence]
                                current_len = sum(len(x) for x in current_chunk) + len(current_chunk) - 1
                            else:
                                current_chunk.append(sentence)
                                current_len += s_len + 1
                    elif current_len + p_len > self.max_chunk_size and current_chunk:
                        chunk_text = "\n\n".join(current_chunk)
                        chunks.append(self._create_chunk_dict(chunk_text, source_file, safe_source_id, current_header, len(chunks)))
                        # Aplicar solapamiento (overlap) del fragmento anterior
                        overlap_text = chunk_text[-self.overlap:] if len(chunk_text) > self.overlap else chunk_text
                        current_chunk = [overlap_text, p] if self.overlap > 0 else [p]
                        current_len = sum(len(x) for x in current_chunk) + len(current_chunk) - 1
                    else:
                        current_chunk.append(p)
                        current_len += p_len + 2

                if current_chunk:
                    chunk_text = "\n\n".join(current_chunk)
                    chunks.append(self._create_chunk_dict(chunk_text, source_file, safe_source_id, current_header, len(chunks)))
            else:
                chunks.append(self._create_chunk_dict(sec_text, source_file, safe_source_id, current_header, len(chunks)))

        logger.info(f"Creados {len(chunks)} fragmentos semánticos para '{source_file}'")
        return chunks

    def _create_chunk_dict(self, content: str, source_file: str, safe_source_id: str, header: str, idx: int) -> Dict[str, Any]:
        return {
            "id": f"{safe_source_id}_chunk_{idx}",
            "content": content,
            "metadata": {
                "source_file": source_file,
                "header": header,
                "chunk_idx": idx,
                "char_length": len(content),
            },
        }
